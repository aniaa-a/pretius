package pl.com.kosan.segregation.service;


import java.io.IOException;


public interface CatalogService {

    void createCatalogStructure();

    void searchHomeCatalogAndMoveFile() throws IOException;

}
