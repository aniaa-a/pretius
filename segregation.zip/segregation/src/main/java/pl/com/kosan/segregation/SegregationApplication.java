package pl.com.kosan.segregation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import pl.com.kosan.segregation.Watcher.DirectoryWatcherService;


import java.io.IOException;

@SpringBootApplication
public class SegregationApplication {


	public static void main(String[] args) {
		SpringApplication.run(SegregationApplication.class, args);

		DirectoryWatcherService ds = new DirectoryWatcherService();
		try {
			ds.runWatcher();
		} catch (IOException e) {
			e.printStackTrace();
		}


	}
}
