package pl.com.kosan.segregation.Watcher;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pl.com.kosan.segregation.service.CatalogService;

import java.io.IOException;
import java.nio.file.*;

@Service
public class DirectoryWatcherService {

    @Autowired
     CatalogService catalogService;


    public void runWatcher() throws IOException {

        catalogService.createCatalogStructure();

        WatchService watchService
                = FileSystems.getDefault().newWatchService();

        Path path = Paths.get( "HOME");

        WatchKey watchKey = path.register(
                watchService,
                StandardWatchEventKinds.ENTRY_CREATE,
                StandardWatchEventKinds.ENTRY_DELETE,
                StandardWatchEventKinds.ENTRY_MODIFY);


        while (true) {
            for (WatchEvent<?> event : watchKey.pollEvents()) {
                catalogService.searchHomeCatalogAndMoveFile();
            }
            watchKey.reset();
        }
    }

}