package pl.com.kosan.segregation.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.List;

import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;

@Service
public class CatalogServiceImpl implements CatalogService {

    private static final Logger LOG = LoggerFactory.getLogger(CatalogServiceImpl.class);


    @Override
    public void createCatalogStructure() {

        final List<String> CATALOGSLIST = Arrays.asList("HOME", "DEV", "TEST");

        for (String catalog : CATALOGSLIST) {
            try {
                Files.createDirectories(Paths.get( catalog));
            } catch (IOException e) {
                LOG.error("can't create path :" + catalog);
            }
        }
    }

    @Override
    public void searchHomeCatalogAndMoveFile() throws IOException {

        Files.walk(Paths.get("HOME"), 1)
                .forEach(f -> {
                    try {
                        if (f.toFile().toString().endsWith(".jar")) {

                            String day = checkDay(f);
                            if (Integer.valueOf(day) % 2 == 0) {
                                Files.move(f, Paths.get( "DEV"), REPLACE_EXISTING);
                            } else {
                                Files.move(f, Paths.get( "TEST"), REPLACE_EXISTING);
                            }

                        } else if (f.endsWith(".xml")) {
                            Files.move(f, Paths.get("DEV"), REPLACE_EXISTING);
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                });

    }

    private String checkDay(Path file) throws IOException {
        BasicFileAttributes attr = Files.readAttributes(file, BasicFileAttributes.class);
        FileTime time = attr.creationTime();
        DateFormat df = new SimpleDateFormat("HH:mm:ss dd/MM/yyyy");
        String date = df.format(time.toMillis());
        String[] dateParts = date.split(":");
        return dateParts[0];
    }
}
