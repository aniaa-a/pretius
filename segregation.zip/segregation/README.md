Budowanie programu

Proces budowy rozpoczynamy wpisując komende w folderze głównym:
mvn clean install
w przybadku braku narzędzia maven można skorzystać z wersji przesyłanej wraz z kodem:
./mvnw clean install

Startowanie Aplikacji

instrukcja mvn spring-boot:run

bądź

java -jar segregation-0.0.1-SNAPSHOT.jar